//sets a simple parameter - in this case the spin speed of the dolphin;
var spinSpeed = 0.02;
var moveForwardVelocity = 0.2;
var moveBackwardVelocity = 0.2;
var moveLeftVelocity = -0.2;
var moveRightVelocity = -0.2;
var rotate = 2.0;
