package a3;

import myGameEngine.Networking.ProtocolClient;
import myGameEngine.Networking.GhostAvatar;
import myGameEngine.Networking.NetworkingServer;
import myGameEngine.Networking.GameServerUDP;

import myGameEngine.Actions.MoveForwardAction;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.io.*;


import java.util.UUID;
import java.util.Vector;
import java.util.Iterator;
import java.net.UnknownHostException;
import java.net.InetAddress;

import ray.rage.*;
import ray.rage.game.*;
import ray.rage.rendersystem.*;
import ray.rage.rendersystem.Renderable.*;
import ray.rage.rendersystem.states.*;
import ray.rage.rendersystem.gl4.GL4RenderSystem;
import ray.rage.scene.*;
import ray.rage.scene.Camera.Frustum.*;
import ray.rage.scene.controllers.*;
import ray.rage.asset.texture.*;
import ray.rage.util.*;

import ray.networking.IGameConnection.ProtocolType;

import ray.input.*;
import ray.input.action.*;

import net.java.games.input.Controller;
import net.java.games.input.ControllerEnvironment;
import net.java.games.input.Version;
import net.java.games.input.Component;

import ray.rml.*;

public class MyGame extends VariableFrameRateGame {

	// to minimize variable allocation in update()
	GL4RenderSystem rs;
	float elapsTime = 0.0f;
	String elapsTimeStr, counterStr, dispStr;
	int elapsTimeSec, counter = 0;
	
	private SceneManager sm;
	private SceneNode dolphinN;
	
	private InputManager im = new GenericInputManager();
	
	private String serverAddress;
	private int serverPort;
	private ProtocolType serverProtocol;
	private ProtocolClient protClient;
	private boolean isClientConnected;
	private Vector<UUID> gameObjectsToRemove;
	
	private static final String SKYBOX_NAME = "SkyBox";
	private boolean skyBoxVisible = true;

    public MyGame(String serverAddr, int sPort) {
        super();
		serverAddress = serverAddr;
		serverPort = sPort;
		serverProtocol = ProtocolType.UDP; //TCP
		/*System.out.println("press T to render triangles");
		System.out.println("press L to render lines");
		System.out.println("press P to render points");
		System.out.println("press C to increment counter");
		*/
    }

    public static void main(String[] args) {
        Game game = new MyGame(args[0], Integer.parseInt(args[1])); //, args[2]);
        try {
            game.startup();
            game.run();
        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            game.shutdown();
            game.exit();
        }
    }
	
	public void setIsConnected(boolean connected){
			isClientConnected = connected;
	}
	
	private void setupNetworking(){
	
		gameObjectsToRemove = new Vector<UUID>();
		isClientConnected = false;
		
		try{
			System.out.println("Attempting to get ProtocolClient"); //added for debugging
			protClient = new ProtocolClient(InetAddress.getByName(serverAddress), serverPort, serverProtocol, this);
		}
		catch(UnknownHostException e) {
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		
		if(protClient == null)
			System.out.println("missing protocol host");
		else
			protClient.sendJoinMessage();
	}
	
	protected void setupInputs(){
	
		String gpName = im.getFirstGamepadName();
		
		Action moveForward = new MoveForwardAction(dolphinN, protClient);
		
		im.associateAction(gpName,
			net.java.games.input.Component.Identifier.Button._1,
			moveForward, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
	}
	
	@Override
	protected void setupWindow(RenderSystem rs, GraphicsEnvironment ge) {
		rs.createRenderWindow(new DisplayMode(1000, 700, 24, 60), false);
	}

    @Override
    protected void setupCameras(SceneManager sm, RenderWindow rw) {
        SceneNode rootNode = sm.getRootSceneNode();
        Camera camera = sm.createCamera("MainCamera", Projection.PERSPECTIVE);
        rw.getViewport(0).setCamera(camera);
		
		camera.setRt((Vector3f)Vector3f.createFrom(1.0f, 0.0f, 0.0f));
		camera.setUp((Vector3f)Vector3f.createFrom(0.0f, 1.0f, 0.0f));
		camera.setFd((Vector3f)Vector3f.createFrom(0.0f, 0.0f, -1.0f));
		
		camera.setPo((Vector3f)Vector3f.createFrom(0.0f, 0.0f, 0.0f));

        SceneNode cameraNode = rootNode.createChildSceneNode(camera.getName() + "Node");
        cameraNode.attachObject(camera);
    }
	
    @Override
    protected void setupScene(Engine eng, SceneManager sm) throws IOException {
		this.sm = sm;
	//*******Set up sky box
		setupSkybox(eng);
	
	//*******add dolphin to scene, currently this is our "avatar"
        Entity dolphinE = sm.createEntity("myDolphin", "dolphinHighPoly.obj");
        dolphinE.setPrimitive(Primitive.TRIANGLES);

        dolphinN = sm.getRootSceneNode().createChildSceneNode(dolphinE.getName() + "Node");
        dolphinN.moveBackward(2.0f);
        dolphinN.attachObject(dolphinE);

	//******Lighting
        sm.getAmbientLight().setIntensity(new Color(.1f, .1f, .1f));
		
		Light plight = sm.createLight("testLamp1", Light.Type.POINT);
		plight.setAmbient(new Color(.3f, .3f, .3f));
        plight.setDiffuse(new Color(.7f, .7f, .7f));
		plight.setSpecular(new Color(1.0f, 1.0f, 1.0f));
        plight.setRange(5f);
		
		SceneNode plightNode = sm.getRootSceneNode().createChildSceneNode("plightNode");
        plightNode.attachObject(plight);

        //RotationController rc = new RotationController(Vector3f.createUnitVectorY(), .02f);
        //rc.addNode(dolphinN);
        //sm.addController(rc);
		
		setupNetworking();
		setupInputs();
    }
	
	protected void setupSkybox(Engine eng) throws IOException{
		
		Configuration conf = eng.getConfiguration();
		TextureManager tm = getEngine().getTextureManager();
		tm.setBaseDirectoryPath(conf.valueOf("assets.skyboxes.mypath"));
		Texture front = tm.getAssetByPath("front.jpg");
		Texture back = tm.getAssetByPath("back.jpg");
		Texture left = tm.getAssetByPath("left.jpg");
		Texture right = tm.getAssetByPath("right.jpg");
		Texture top = tm.getAssetByPath("top.jpg");
		Texture bottom = tm.getAssetByPath("bottom.jpg");
		tm.setBaseDirectoryPath(conf.valueOf("assets.textures.path"));
		
		
		AffineTransform xform = new AffineTransform();
		xform.translate(0, front.getImage().getHeight());
		xform.scale(1d, -1d);
		
		front.transform(xform);
		back.transform(xform);
		left.transform(xform);
		right.transform(xform);
		top.transform(xform);
		bottom.transform(xform);
		
		SkyBox sb = sm.createSkyBox(SKYBOX_NAME);
		sb.setTexture(front, SkyBox.Face.FRONT);
		sb.setTexture(back, SkyBox.Face.BACK);
		sb.setTexture(left, SkyBox.Face.LEFT);
		sb.setTexture(right, SkyBox.Face.RIGHT);
		sb.setTexture(top, SkyBox.Face.TOP);
		sb.setTexture(bottom, SkyBox.Face.BOTTOM);
		sm.setActiveSkyBox(sb);
	}

    @Override
    protected void update(Engine engine) {
		// build and set HUD
		rs = (GL4RenderSystem) engine.getRenderSystem();
		elapsTime += engine.getElapsedTimeMillis();
		elapsTimeSec = Math.round(elapsTime/1000.0f);
		elapsTimeStr = Integer.toString(elapsTimeSec);
		counterStr = Integer.toString(counter);
		dispStr = "Time = " + elapsTimeStr + "   Keyboard hits = " + counterStr;
		rs.setHUD(dispStr, 15, 15);
		
		processNetworking(elapsTime);
		im.update(elapsTime);
		
	}
	
	protected void processNetworking(float elapsTime){
		
		if(protClient != null)
			protClient.processPackets();
		
		Iterator<UUID> it = gameObjectsToRemove.iterator();
		while(it.hasNext())
			sm.destroySceneNode(it.next().toString());
		
		gameObjectsToRemove.clear();
	}
	
	public Vector3 getPlayerPosition(){
		return dolphinN.getWorldPosition();
	}
	
	public void addGhostAvatarToGameWorld(GhostAvatar avatar) throws IOException{
		if(avatar != null){
			System.out.println("Creating ghost avatar");
			Entity ghostE = sm.createEntity("ghost", "sphere.obj");
			ghostE.setPrimitive(Primitive.TRIANGLES);
			SceneNode ghostN = sm.getRootSceneNode().createChildSceneNode(avatar.getID().toString());
			ghostN.attachObject(ghostE);
			ghostN.setLocalPosition(0, 0 , -4); //these hardcoded numbers need some enumeration later
			avatar.setNode(ghostN);
			avatar.setEntity(ghostE);
			//avatar.setPosition(); sample says this could be redundent. Leaving it commented out for now
		}
	}
	
	public void removeGhostAvatarFromGameWorld(GhostAvatar avatar){
		if(avatar != null)
			gameObjectsToRemove.add(avatar.getID());
	}
	
	

    @Override
    public void keyPressed(KeyEvent e) {
        Entity dolphin = getEngine().getSceneManager().getEntity("myDolphin");
        switch (e.getKeyCode()) {
            case KeyEvent.VK_L:
                dolphin.setPrimitive(Primitive.LINES);
                break;
            case KeyEvent.VK_T:
                dolphin.setPrimitive(Primitive.TRIANGLES);
                break;
            case KeyEvent.VK_P:
                dolphin.setPrimitive(Primitive.POINTS);
                break;
			case KeyEvent.VK_C:
				counter++;
				break;
        }
        super.keyPressed(e);
    }
}
