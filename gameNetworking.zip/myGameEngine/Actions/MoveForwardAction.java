package myGameEngine.Actions;

import myGameEngine.Networking.ProtocolClient;

import ray.input.action.AbstractInputAction;
import ray.rage.scene.*;

import ray.rml.*;
import net.java.games.input.Event;


public class MoveForwardAction extends AbstractInputAction{
	
		private Node avN;
		private ProtocolClient protClient;
	
		public MoveForwardAction(Node n, ProtocolClient p){
			avN = n;
			protClient = p;
		}
		
		public void performAction(float time, Event e){
			//System.out.println("Move forward");
			avN.moveForward(0.1f);
			
			if(protClient != null)
				protClient.sendMoveMessage(avN.getWorldPosition());
		}
}